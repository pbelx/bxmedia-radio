// Don't forget to make the changes mentioned in
// https://github.com/bitsdojo/bitsdojo_window#getting-started

import 'package:flutter/material.dart';
import 'package:bitsdojo_window/bitsdojo_window.dart';
// import 'package:audioplayers/audioplayers.dart';
// import 'package:http/http.dart' as http;
// import 'dart:convert';

// import 'package:musik/pages/__left_side_state.dart';
import 'package:musik/pages/left_side.dart';
import 'package:musik/pages/right_side.dart';

void main() {
  appWindow.size = const Size(600, 450);
  runApp(const MyApp());
  appWindow.show();
  doWhenWindowReady(() {
    final win = appWindow;
    const initialSize = Size(600, 450);
    const maxSize = Size(600, 500);
    win.minSize = initialSize;
    win.size = initialSize;
    win.maxSize = maxSize;
    win.alignment = Alignment.center;
    win.title = "Custom window with Flutter";
    win.show();
  });
}

const borderColor = Color.fromARGB(255, 204, 179, 136);

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: Scaffold(
        body: WindowBorder(
          color: borderColor,
          width: 1,
          child: const Row(
            children: [LeftSide(), RightSide()],
          ),
        ),
      ),
    );
  }
}

const sidebarColor = Color.fromARGB(255, 17, 6, 1);

const backgroundStartColor = Color.fromARGB(255, 156, 29, 6);
const backgroundEndColor = Color.fromARGB(255, 49, 13, 3);

final buttonColors = WindowButtonColors(
    iconNormal: const Color.fromARGB(255, 214, 196, 163),
    mouseOver: const Color.fromARGB(255, 240, 229, 210),
    mouseDown: const Color(0xFF805306),
    iconMouseOver: const Color.fromARGB(255, 170, 161, 145),
    iconMouseDown: const Color.fromARGB(255, 187, 183, 162));

final closeButtonColors = WindowButtonColors(
    mouseOver: const Color(0xFFD32F2F),
    mouseDown: const Color(0xFFB71C1C),
    iconNormal: const Color.fromARGB(255, 245, 241, 233),
    iconMouseOver: Colors.white);

class WindowButtons extends StatefulWidget {
  const WindowButtons({super.key});

  @override
  State<WindowButtons> createState() => _WindowButtonsState();
}

class _WindowButtonsState extends State<WindowButtons> {
  void maximizeOrRestore() {
    setState(() {
      appWindow.maximizeOrRestore();
    });
  }

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        MinimizeWindowButton(colors: buttonColors),
        appWindow.isMaximized
            ? RestoreWindowButton(
                colors: buttonColors,
                onPressed: maximizeOrRestore,
              )
            : MaximizeWindowButton(
                colors: buttonColors,
                onPressed: maximizeOrRestore,
              ),
        CloseWindowButton(colors: closeButtonColors),
      ],
    );
  }
}

class RadioStation {
  final String name;
  final String? streamUrl;

  RadioStation(this.name, this.streamUrl);
}
