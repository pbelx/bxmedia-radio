import 'package:flutter/material.dart';
import 'package:carousel_slider/carousel_slider.dart';
// import 'dart:math';
import 'package:bitsdojo_window/bitsdojo_window.dart';
import '../main.dart';

class RandomImageCarousel extends StatefulWidget {
  const RandomImageCarousel({Key? key}) : super(key: key);

  @override
  _RandomImageCarouselState createState() => _RandomImageCarouselState();
}

class _RandomImageCarouselState extends State<RandomImageCarousel> {
  final List<String> imageUrls = [
    'https://picsum.photos/500/300?random=1',
    'https://picsum.photos/500/300?random=2',
    'https://picsum.photos/500/300?random=3',
    'https://picsum.photos/500/300?random=4',
    'https://picsum.photos/500/300?random=5',
  ];

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        WindowTitleBarBox(
          child: Row(
            children: [Expanded(child: MoveWindow()), const WindowButtons()],
          ),
        ),
        Expanded(
          child: CarouselSlider(
            options: CarouselOptions(
              height: 300.0,
              enlargeCenterPage: true,
              autoPlay: true,
              aspectRatio: 16 / 9,
              autoPlayCurve: Curves.fastOutSlowIn,
              enableInfiniteScroll: true,
              autoPlayAnimationDuration: const Duration(milliseconds: 800),
              viewportFraction: 0.8,
            ),
            items: imageUrls.map((url) {
              return Builder(
                builder: (BuildContext context) {
                  return Container(
                    width: MediaQuery.of(context).size.width,
                    margin: const EdgeInsets.symmetric(horizontal: 5.0),
                    decoration: const BoxDecoration(color: Colors.grey),
                    child: Image.network(
                      url,
                      fit: BoxFit.cover,
                    ),
                  );
                },
              );
            }).toList(),
          ),
        ),
      ],
    );
  }
}
