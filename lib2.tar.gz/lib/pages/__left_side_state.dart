// Don't forget to make the changes mentioned in
// https://github.com/bitsdojo/bitsdojo_window#getting-started

import 'dart:convert';
import 'package:audioplayers/audioplayers.dart';
import 'package:bitsdojo_window/bitsdojo_window.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:musik/main.dart';
import 'package:musik/pages/left_side.dart';

class LeftSideState extends State<LeftSide> {
  final AudioPlayer _audioPlayer = AudioPlayer();
  List<RadioStation> stations = [];
  bool isLoading = true;
  int currentStationIndex = 0;
  bool isPlaying = false;
  double volume = 0.5;
  String streamlink = "https://entebbe.fun:8443/stream/";

  @override
  void initState() {
    super.initState();
    fetchStations();
  }

  Future<void> fetchStations() async {
    try {
      final response =
          await http.get(Uri.parse('https://entebbe.fun:8443/stations'));
      // await http.get(Uri.parse('https://bx.cybertv.tv:2053/all2/'));

      if (response.statusCode == 200) {
        final List<dynamic> stationList = json.decode(response.body);
        // print(stationList);
        setState(() {
          stations = stationList
              .map((station) => RadioStation(
                    station['name'],
                    station['url'],
                  ))
              .toList();
          isLoading = false;
        });
      } else {
        throw Exception('Failed to load stations');
      }
    } catch (e) {
      print('Error fetching stations: $e');
      setState(() {
        isLoading = false;
      });
    }
  }

  void _playStation(int index) async {
    if (index >= 0 && index < stations.length) {
      try {
        // await _audioPlayer.play(UrlSource(stations[index].streamUrl));
        final String stationUrl = "$streamlink${stations[index].name}";
        await _audioPlayer.play(UrlSource(stationUrl));
        setState(() {
          currentStationIndex = index;
          isPlaying = true;
        });
      } catch (e) {
        print('Error playing station: $e');
      }
    }
  }
  // void _playStation(int index) async {
  //   if (index >= 0 && index < stations.length) {
  //     try {
  //       // Stop any current playback
  //       await _audioPlayer.stop();

  //       final String stationUrl = "$streamlink${stations[index].name}";

  //       // Set audio source
  //       await _audioPlayer.setSourceUrl(stationUrl);

  //       // Play the audio
  //       await _audioPlayer.resume();

  //       setState(() {
  //         currentStationIndex = index;
  //         isPlaying = true;
  //       });
  //     } catch (e) {
  //       print('Error playing station: $e');
  //       setState(() {
  //         isPlaying = false;
  //       });
  //       // Optional: Show a snackbar or dialog to user about connection issues
  //       // ignore: use_build_context_synchronously
  //       ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
  //           content: Text('Unable to play station. Check your connection.')));
  //     }
  //   }
  // }

  void _togglePlayPause() {
    if (isPlaying) {
      _audioPlayer.stop();
    } else {
      // _audioPlayer.play(stations[currentStationIndex].streamUrl);
      _audioPlayer.resume();
    }
    setState(() {
      isPlaying = !isPlaying;
    });
  }

  void _changeVolume(double change) {
    setState(() {
      volume = (volume + change).clamp(0.0, 1.0);
      _audioPlayer.setVolume(volume);
    });
  }

  Widget _buildStationInfo(RadioStation station) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        Text(
          station.name,
          style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
        ),
        SizedBox(width: 10),
        Icon(Icons.favorite, color: Colors.red),
      ],
    );
  }

  Widget _buildControlsAndPlaylist() {
    return Padding(
      padding: const EdgeInsets.all(8.0),
      child: Column(
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: [
              IconButton(
                icon: Icon(Icons.remove, color: Colors.grey[200]),
                onPressed: () => _changeVolume(-0.1),
              ),
              IconButton(
                icon: Icon(
                  Icons.skip_previous,
                  color: Colors.white70,
                ),
                onPressed: () => _playStation(currentStationIndex - 1),
              ),
              IconButton(
                icon: Icon(isPlaying ? Icons.pause : Icons.play_arrow,
                    size: 32, color: Colors.white70),
                onPressed: _togglePlayPause,
              ),
              IconButton(
                icon: Icon(Icons.skip_next, color: Colors.white70),
                onPressed: () => _playStation(currentStationIndex + 1),
              ),
              IconButton(
                icon: Icon(Icons.add, color: Colors.grey[200]),
                onPressed: () => _changeVolume(0.1),
              ),
            ],
          ),
          SizedBox(height: 20),
          // Add playlist or additional station info here
        ],
      ),
    );
  }

  Widget _buildStationList() {
    return Container(
      height: 250, // Fixed height for the station list
      decoration: BoxDecoration(
        color: Colors.black,
        boxShadow: [
          BoxShadow(
            color: Colors.grey.withOpacity(0.5),
            spreadRadius: 1,
            blurRadius: 3,
            offset: const Offset(0, -2),
          ),
        ],
      ),
      child: ListView.builder(
        itemCount: stations.length,
        itemBuilder: (context, index) {
          return Padding(
            padding: const EdgeInsets.only(left: 30, right: 10),
            child: ListTile(
              title: Text(stations[index].name,
                  style: TextStyle(color: Colors.grey[100])),
              onTap: () => _playStation(index),
              trailing: Icon(
                Icons.music_note,
                color: Colors.grey[500],
              ),
              selected: index == currentStationIndex,
              // selectedTileColor: Colors.red,
            ),
          );
        },
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return SizedBox(
        width: 250,
        child: Container(
            color: sidebarColor,
            child: Column(
              children: [
                WindowTitleBarBox(child: MoveWindow()),
                Expanded(
                    child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    currentStationIndex == 0
                        ? const Text(
                            // stations[currentStationIndex].name,
                            'Online Radio',
                            style: TextStyle(fontSize: 18, color: Colors.white),
                            textAlign: TextAlign.center,
                          )
                        : Text(
                            stations[currentStationIndex].name,
                            style: TextStyle(fontSize: 18, color: Colors.white),
                            textAlign: TextAlign.center,
                          ),
                    _buildControlsAndPlaylist(),
                    _buildStationList(),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.end,
                      children: [
                        SizedBox(
                          height: 5,
                        ),
                        IconButton(
                          onPressed: () {
                            fetchStations();
                          },
                          icon: const Icon(Icons.refresh),
                          color: Colors.white70,
                        )
                      ],
                    )
                  ],
                ))
              ],
            )));
  }
}
