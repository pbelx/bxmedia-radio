// Don't forget to make the changes mentioned in
// https://github.com/bitsdojo/bitsdojo_window#getting-started

// import 'package:bitsdojo_window/bitsdojo_window.dart';
import 'package:flutter/material.dart';
import 'package:musik/main.dart';
import 'package:musik/pages/randomImage.dart';

class RightSide extends StatelessWidget {
  const RightSide({super.key});
  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
              colors: [backgroundStartColor, backgroundEndColor],
              stops: [0.0, 1.0]),
        ),
        // child: Column(children: [
        //   WindowTitleBarBox(
        //     child: Row(
        //       children: [
        //         Expanded(child: MoveWindow()),
        //         const WindowButtons(),
        //         RandomImageCarousel()
        //       ],
        //     ),
        //   )
        // ]),
        child: RandomImageCarousel(),
      ),
    );
  }
}
